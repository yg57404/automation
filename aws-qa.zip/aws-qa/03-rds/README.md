# USAGE

- Used to create RDS resource with Postgres and MySQL engines.
- Contains the following features:
  1. Multi-az RDS deployment.
  2. Creation of a new security group with CIDR or Security group or both as ingress source on port for RDS.
  3. Engine version and Parameter Group configurations based on database engine.
  4. Generate a random master password.
  5. Custom storage input size.
  6. Encrypted storage (with default or custom grenerated key)
  7. Maintainence slot and backup window for prod env.
  8. Option to skip final snapshot.
  9. Launch RDS in multiple subnets. 
  10. Enable/Disable Deletion Protection.
  11. Creates a new parameter group.
  12. Creates a new option group.
  13. Cloudwatch monitoring and log exporting.
  14. Enable/Disable Apply Immediately for changes.
  15. Create RDS from snapshot of another database. 
  16. SSL/TLS encrypted connection and parameter.


- To store the ***.tfstate*** file in provisioned cloud backend edit ***backend.tf*** .

```
NOTE: The paremeter KEY in backend.tf is the path in the backend S3 bucket where the .tfstate for each module will be stored. Make sure that the path is not the same for different modules.
```
- The folder named ***vars*** contains 4 different tfvars files for different use cases:

        - Postgres:
            - Non Prod: For setting up RDS with PostgreSQL engine with non prod env configs.
            - Prod: For setting up RDS with PostgreSQL engine with prod env configs.
        - MySQL:  
            - Non Prod: For setting up RDS with MySQL engine with non prod env configs.
            - Prod: For setting up RDS with PostgreSQL engine with prod env configs.

- To pass custom values for rds edit one of the files from ***.tfvars.reference*** in vars folder and change it to ***.tfvars*** and pass your values there.

- By default a new RDS dedicated security group is created.Choose the ingress source from the following options:
   1. CIDR ingress - Enter CIDR value
   2. Existing security group ingress - Enter security group ID.
   3. Use both CIDR and allowed_security_groups by entering values.

- To apply  :

        cd aws/03-rds
        terraform init
        terraform plan -var-file=vars/rds_mysql_prod.tfvars -out plan.out   
        terraform apply plan.out 

- To destroy the resources:

      terraform destroy -var-file=vars/rds_mysql_prod.tfvars

# CIS COMPLIANCE 

- Follows the VPC recommendations of CIS Amazon Web Services Foundations Benchmark v1.4.0  

 2.3.1 | Ensure that encryption is enabled for RDS instances                                                                |   OK  |             Enabled for RDS created using this module.                                                                                                                           