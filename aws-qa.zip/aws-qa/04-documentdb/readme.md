# USAGE

- Used to create DocumentDB cluster. 
- Contains the following features:
 
  1. Deployed in public or private subnets.
  2. Creation of a new security gorup with CIDR or Security group or both as ingress source.
  3. Number of instances in cluster.
  4. Enable/Disable Apply Immediately for changes.
  5. Maintainence slot and backup window for prod env databases.
  6. Backup window and retention period for prod env databases. 
  7. Encrypt storage with default key or by using a custom genetrated key.
  8. SSL/TLS encypted connections by default.


- To store the ***.tfstate*** file in provisioned cloud backend edit ***backend.tf*** .

```
NOTE: The paremeter KEY in backend.tf is the path in the backend S3 bucket where the .tfstate for each module will be stored. Make sure that the path is not the same for different modules.
```
- The folder named ***vars*** contains 2 different tfvars files for different use cases:

      - Non Prod: Contains non prod env configs.
      - Prod: Contains prod env configs.


- To pass custom values for document edit one of the files from ***documentdb.tfvars.reference*** in vars folder and change it to ***documentdb.tfvars*** and pass your values there.

- By default a new DocumentDB dedicated security group is created.Choose the ingress source from the following options:
   1. CIDR ingress - Enter CIDR value
   2. Existing security group ingress - Enter security group ID.
   3. Use both CIDR and allowed_security_groups by entering values.

- To apply  :

        cd aws/04-documentdb
        terraform init
        terraform plan -var-file=vars/documentdb_nonprod.tfvars -out plan.out   
        terraform apply plan.out 

- To destroy the resources:

      terraform destroy -var-file=vars/documentdb_nonprod.tfvars



