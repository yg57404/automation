# USAGE

- Used to create RDS resource with Postgres and MySQL engines.
- Contains the following features:
  1. Engine Mode for provisioned or serverless.
  2. Creation of a new security gorup with CIDR or Security group or both as ingress source.
  3. Engine version and Parameter Group configurations based on database engine.
  4. Generate a random master password.
  5. Number of replicas to create in cluster.
  6. Encrypted storage (with default or custom grenerated key)
  7. Maintainence slot and backup window for prod env.
  8. Option to skip final snapshot.
  9. Launch RDS in multiple subnets. 
  10. Enable/Disable Deletion Protection.
  11. Creates a new parameter group and cluster parameter group.
  12. Cloudwatch monitoring and log export. 
  13. Enable/Disable Apply Immediately for changes.
  14. SSL/TLS encryuption for connections.


- To store the ***.tfstate*** file in provisioned cloud backend edit ***backend.tf*** .

```
NOTE: The paremeter KEY in backend.tf is the path in the backend S3 bucket where the .tfstate for each module will be stored. Make sure that the path is not the same for different modules.
```
- The folder named ***vars*** contains 2 different folders for ***provisioned*** and ***serverless*** for different engine modes.These folders contains:
        
        -Provisioned:
            - PostgreSQL:
                - Non Prod: For setting up Provisiosned RDS Aurora PostgreSQL with non prod env configs.
                - Prod: For setting up Provisioned RDS Aurora PostgreSQL with prod env configs.
            - MySQL:  
                - Non Prod: For setting up Provisioned RDS Aurora MySQL with non prod env configs.
                - Prod: For setting up Provisioned RDS Aurora MySQL with prod env configs.
        - Serverless:
            - PostgreSQL:
                - Dev: For setting up Serverless RDS Aurora PostgreSQL.
            - MySQL:
                - Dev: For setting up Serverless RDS Aurora PostgreSQL.

- To pass custom values for rds-aurora edit one of the files from ***.tfvars.reference*** in vars folder and change it to ***.tfvars*** and pass your values there.

- To apply  :

        cd aws/06-rds-aurora
        terraform init
        terraform plan -var-file=vars/provisioned/rds_aurora_mysql_non_prod.tfvars -out plan.out   
        terraform apply plan.out 

- To destroy the resources:

      terraform destroy -var-file=vars/provisioned/rds_aurora_mysql_non_prod.tfvars


# CIS COMPLIANCE 

- Follows the VPC recommendations of CIS Amazon Web Services Foundations Benchmark v1.4.0  

 2.3.1 | Ensure that encryption is enabled for RDS instances                                                                |   OK  |             Enabled for RDS created using this module.  