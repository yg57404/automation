# NOTE

- The Pritunl keys and security credentials will be available in the file 'pritunl-info.txt' after the successful execution of 'Terraform Apply' command.