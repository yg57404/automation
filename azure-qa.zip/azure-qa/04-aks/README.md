# USAGE

- Used to create Azure AKS(Azure Kubernetes Service). 
- Contains the following features:
  1. Creates an AKS cluster with different node groups consisting of "SPOT" and "ON DEMAND" and "GPU" nodes.
  2. It contains autoscaling of nodegroup.
  3. It contains metrics server.
  4. Creation of ingress nginx crontroller.
  5. Issues certificates with the help of Cluster Issuer.
  6. Conditional use of Kubenet or Azure cni network plugin.
  7. Created default and custom storage class.
  8. The cluster and all its components are encrypted by default.
  9. Add external secrets functionality to store secrets in any cloud or vault. 

- To store the ***.tfstate*** file in provisioned cloud backend edit ***backend.tf***.


- To pass custom values for EKS edit ***aks_cluster.tfvars.reference*** in vars folder to ***aks_cluster.tfvars*** and pass your values there.

- To apply:-

    ```
    cd azure/04-eks
    terraform init
    terraform validate
    terraform plan -var-file=vars/aks_cluster.tfvars -out plan.out  -->  for saving the plan consisting of terraform created resources in plan.out file
    terraform apply "plan.out"

    ```
- After Successful Deployment of source part, you will get the required outputs.

- To clean up the stack, run the following command -

    ```
    terraform destroy -var-file=vars/aks_cluster.tfvars

    ```