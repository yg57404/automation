# USAGE

- Used to create Azure-mysql-database resource with MySQL engines.
- To store the ***.tfstate*** file in provisioned cloud backend edit ***backend.tf*** .
- To apply change the name of ***db.tfvars.reference*** to ***db.tfvars*** and enter DB ingormation in tfvars.

- To apply  :

        cd azure/03-mysql-db
        terraform init
        terraform plan -var-file=vars/rds_mysql_prod.tfvars -out plan.out   
        terraform apply plan.out

- To destroy the resources:

      terraform destroy -var-file=vars/vnet.tfvars