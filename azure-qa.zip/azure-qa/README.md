# Overview
- This repository contains the following folders for resource creation:
 
    - 01-state-storage-backend : for storing remote state in S3 bucket and DynamoDB. 
    - 02-network : To create a Vnet with relevant resources like Network security group.
    - 03-Mysql-db : To create Azure mysql DB. 
    - 04-aks: To create Azure Kubernetes Service.

```NOTE: REFER TO INTERNAL MODULE README FOR MORE DETAILS ON EVERY MODULE ```

## Pre-requisites:
### Install Below utilities
1. Terraform 1.0.0 :- https://www.terraform.io/docs/cli/install/apt.html
2. Kubectl 1.21.0 :- https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/
3. Helm 3.0.0 :- https://helm.sh/docs/intro/install/
4. Azure Cli:- https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt
