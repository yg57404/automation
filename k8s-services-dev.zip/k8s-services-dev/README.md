# Overview

we will be deploy some services like `Rancher`, `Prometheus and BlackBox Exporter`, `Opendistro`, `Jenkins` and `SonarQube`.

`Rancher` - For controlling up the cluster over UI.

`Prometheus and BlackBox Exporter`-
  - `Prometheus` - For monitoring our applications and deployed infrastructure like what is the current CPU usage of pods, current   disk usage of worker node and much more.
  - `BlackBox Exporter` - For monitoring the HTTP Probe Duration last 5 minutes or is SSL certificate is getting expired or not.

`Opendistro` - For storing and performing certain actions on the logs of the pods.

`Jenkins` - For performing CICD workflow.

`SonarQube` - For scanning the code quality and figuring out the bugs into the code.


## Pre-requisites:
### Install Below utilities
1. Terraform 1.0.0 :- https://www.terraform.io/docs/cli/install/apt.html
2. Kubectl 1.21.0 :- https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/
3. Helm 3.0.0 :- https://helm.sh/docs/intro/install/
#### Prerequisites as per each Cloud Providers  :
4. Aws cli 2:- https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2-linux.html
5. Azure cli 2.20.0 : https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt 
6. Updtae `kube-config file` into your local system after updating cluster name and region below command:-

    EKS: 
    ```
    aws eks update-kubeconfig --name cluster_name --region region_name
    ```
    AKS:
    ```
    az aks get-credentials --name cluster_name --resource-group ResourceGroup_name
    ```
7. please map your nginx-ingress endpoint with your custom dns name.

## Steps to Deploy Services

```
git clone git@gitlab.com:squareops/k8s-services.git
cd k8s-services/
cd vars
mv terraform.tfvars.reference terraform.tfvars    #Rename terraform.tfvars.reference
nano terraform.tfvars
```
Note:- 

    - In `terraform.tfvars`, The services which you want to deploy will set to true rest all will be false and also define dns name as you mapped ingress ip. if you are deploying rancher then update let'sencrypt email and dns.

    - If you are using Existing cluster please perform the following steps:-
    1. Access any of the service folder eg. ci-cd
    2. Choose desired service eg. ci-cd/jenkins
    3. Edit the file helm/values/values.yaml and Enter existing values Such as name of storage class and affinity.

    - If you have any application endpoint and you want to monitor that, please update the endpoint in prometheus-values.yaml and path is observability/prometheus-grafana-loki/helm/values/prometheus-values.yaml in "additionalScrapeConfigs" section. 

- Please Update Backed.tf file as per each Cloud Providers by performing the following steps:-
  1. For aws replace backend.tf.aws to backend.tf and pass your values.
  2. For azure replace backend.tf.azure to backend.tf and pass your values.
  3. For gcp replace backend.tf.gcp to backend.tf and pass your values.

- To create the stack, run the following command -

    ```
    cd ../
    terraform init
    terraform validate
    terraform plan -var-file=vars/terraform.tfvars -out plan.out
    terraform apply "plan.out" 
    ```
    
- Note:-

  - After Successful Deployment of services you will get the required outputs like `Urls`, `UserName`, `Password` etc.

  - If your are not getting `Username` and `Password` in output then it will be username `admin` Password `admin` by default.

  - If you have enabled grafana then `Prometheus, loki and BlackBox Exporter` will be deplyed along with it.


- To clean up the stack, run the following command -

    ```
    terraform destroy -var-file=vars/terraform.tfvars
    ```
  
### For running security scan in the cluster - ###

- Their is file with name kube-scan-lb.yaml, you have to run `kubectl apply -f ./security/kube-scan-lb.yaml` which will deploy some components and navigate to AWS Console -> EC2 -> Load Balancers, here you will see a NLB, do click on `DNS Record` of NLB which will give a UI and you will see a page where several deployments, daemonsets and statefulsets deployed in the cluster will be present.


- Note - Make sure to run `kubectl delete -f ./security/kube-scan-lb.yaml` before destroying the terraform stack.